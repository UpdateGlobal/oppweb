// JavaScript Document
function visitante(){
	alert("Esta opción no está disponible para visitas.")
}