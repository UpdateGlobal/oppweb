
// initialize app
//
+function($) {
  app.init();
  topbar.init();
  sidebar.init();
  topbar_menu.init();
  quickview.init();
  dock.init();
  aside.init();
  lookup.init();

  cards.init();

  app.isReady();

}(jQuery);

