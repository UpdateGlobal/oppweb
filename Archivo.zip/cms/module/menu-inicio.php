<div class="header-action">
	<nav class="nav">
    	<a class="nav-link <?php echo ($page == "metatags" ? "active" : "")?>" href="metatags.php">Metatags</a>
        <a class="nav-link <?php echo ($page == "banners" ? "active" : "")?>" href="banners.php">Banners</a>
        <a class="nav-link <?php echo ($page == "carrusel" ? "active" : "")?>" href="carrusel.php">Carrusel</a>
    </nav>
</div>