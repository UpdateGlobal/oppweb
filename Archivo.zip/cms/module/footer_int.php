	<!-- Footer -->
    <footer class="site-footer">
    	<div class="row">
        	<div class="col-md-12">
        		<p class="text-center text-md-left">Copyright &copy; 2018 <a href="index.php">Update Global Admin</a>. Todos los derechos Reservados.</p>
        	</div>
        </div>
    </footer>
    <!-- END Footer -->
    <!-- Scripts -->
    <script src="assets/js/core.min.js"></script>
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/script.min.js"></script>