<div class="header-action">
	<nav class="nav">
    	<a class="nav-link <?php echo ($page == "galeria" ? "active" : "")?>" href="galeria.php">Albums</a>
        <a class="nav-link <?php echo ($page == "galeria-fotos" ? "active" : "")?>" href="galeria-fotos.php">Fotos</a>
        <a class="nav-link <?php echo ($page == "videos" ? "active" : "")?>" href="galeria-videos.php">V&iacute;deos</a>
    </nav>
</div>