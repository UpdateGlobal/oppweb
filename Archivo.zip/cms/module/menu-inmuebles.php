<div class="header-action">
	<nav class="nav">
    	<a class="nav-link <?php echo ($page == "inmueblescategorias" ? "active" : "")?>" href="inmuebles-categorias.php">Categor&iacute;as</a>
        <a class="nav-link <?php echo ($page == "inmuebleslugares" ? "active" : "")?>" href="inmuebles-lugares.php">Lugares</a>
        <a class="nav-link <?php echo ($page == "inmueblesdistritos" ? "active" : "")?>" href="inmuebles-distritos.php">Distritos</a>
        <a class="nav-link <?php echo ($page == "inmuebles" ? "active" : "")?>" href="inmuebles.php">Inmuebles</a>
    	<a class="nav-link <?php echo ($page == "inmueblesfotos" ? "active" : "")?>" href="inmuebles-fotos.php">Fotos</a>
    </nav>
</div>