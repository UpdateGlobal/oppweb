<div class="header-action">
	<nav class="nav">
    	<a class="nav-link <?php echo ($page == "contacto" ? "active" : "")?>" href="contacto.php">Contacto</a>
        <a class="nav-link <?php echo ($page == "mensajes" ? "active" : "")?>" href="mensajes.php">Mensajes</a>
    </nav>
</div>